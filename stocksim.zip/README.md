






I've decided on using long and int for stock's Quantity and Price, since it's simplified version with static pricing, but in production grade code it should've been BigInteger and BigDecimal to not risk overflows/precision issues.