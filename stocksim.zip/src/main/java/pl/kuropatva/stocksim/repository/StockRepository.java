package pl.kuropatva.stocksim.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.kuropatva.stocksim.model.entity.Stock;

import java.util.List;
import java.util.Optional;

public interface StockRepository extends JpaRepository<Stock, Long> {

    Optional<Stock> findByNameAndWalletIsNull(String name);

    Optional<Stock> findByNameAndWalletId(String name, String walletId);

    List<Stock> findAllByWalletId(String walletId);

    void deleteAllByWalletId(String walletId);
}