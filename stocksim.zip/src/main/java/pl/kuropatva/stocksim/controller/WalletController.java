package pl.kuropatva.stocksim.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.kuropatva.stocksim.model.dto.web.TradeRequest;
import pl.kuropatva.stocksim.model.dto.web.WalletDto;
import pl.kuropatva.stocksim.service.TransactionService;
import pl.kuropatva.stocksim.service.WalletService;

@RestController
@RequestMapping("/wallets")
public class WalletController {

    @Autowired
    private TransactionService transactionService;
    @Autowired
    private WalletService walletService;

    @PostMapping("/{walletId}/stocks/{stockName}")
    public void executeTrade(@PathVariable String walletId, @PathVariable String stockName, @RequestBody TradeRequest type) {
        transactionService.executeTrade(walletId, stockName, type);
    }

    @GetMapping("/{walletId}")
    public WalletDto getAllStocks(@PathVariable String walletId) {
        return walletService.getAllStocks(walletId);
    }

    @GetMapping("/{walletId}/stocks/{stockName}")
    public long getStockQuantity(@PathVariable String walletId, @PathVariable String stockName) {
        return walletService.getStockQuantity(walletId, stockName);

    }


}
