package pl.kuropatva.stocksim.service;

import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import pl.kuropatva.stocksim.exception.InsufficientStockException;
import pl.kuropatva.stocksim.exception.StockNotFoundException;
import pl.kuropatva.stocksim.model.dto.web.TradeRequest;
import pl.kuropatva.stocksim.model.entity.AuditLogEntry;
import pl.kuropatva.stocksim.model.entity.Stock;
import pl.kuropatva.stocksim.model.entity.Wallet;
import pl.kuropatva.stocksim.repository.AuditLogRepository;
import pl.kuropatva.stocksim.repository.StockRepository;
import pl.kuropatva.stocksim.repository.WalletRepository;

@Service
@Transactional
public class TransactionService {

    private final WalletRepository walletRepo;
    private final AuditLogRepository logRepo;
    private final StockRepository stockRepo;

    private static final int TRADE_QTY = 1;

    public TransactionService(WalletRepository walletRepo, AuditLogRepository logRepo, StockRepository stockRepo) {
        this.walletRepo = walletRepo;
        this.logRepo = logRepo;
        this.stockRepo = stockRepo;
    }

    public void executeTrade(String walletId, String stockName, TradeRequest tradeRequest) {
        String type = tradeRequest.type().toLowerCase();
        Wallet wallet = walletRepo.findById(walletId).orElseGet(() -> walletRepo.save(new Wallet(walletId)));

        switch (type) {
            case "buy" -> buy(wallet, stockName);
            case "sell" -> sell(wallet, stockName);
            default -> throw new IllegalArgumentException("Unknown transaction type " + type);
        }

        saveLogEntry(walletId, stockName, type);
    }

    private void buy(Wallet wallet, String stockName) {
        var optionalStock = stockRepo.findByNameAndWalletIsNull(stockName);
        if (optionalStock.isEmpty()) {
            throw new StockNotFoundException("No stock with name " + stockName + " was found");
        }
        var bankStock = optionalStock.get();
        if (bankStock.getQuantity() < TRADE_QTY) {
            throw new InsufficientStockException("No stock in bank");
        }

        bankStock.modifyQuantity(-TRADE_QTY);
        Stock walletStock = stockRepo.findByNameAndWalletId(bankStock.getName(), wallet.getId()).orElseGet(() -> {
            Stock s = new Stock(bankStock.getName());
            s.setWallet(wallet);
            return s;
        });

        walletStock.modifyQuantity(TRADE_QTY);

        stockRepo.save(walletStock);
    }

    private void sell(Wallet wallet, String stockName) {

        Stock walletStock = stockRepo.findByNameAndWalletId(stockName, wallet.getId())
                .orElseThrow(() -> new InsufficientStockException("No stock in wallet"));

        if (walletStock.getQuantity() < TRADE_QTY) {
            throw new InsufficientStockException("No stock in wallet");
        }

        walletStock.modifyQuantity(-TRADE_QTY);

        Stock bank = stockRepo.findByNameAndWalletIsNull(stockName)
                .orElse(new Stock(stockName));

        bank.modifyQuantity(TRADE_QTY);
    }

    private void saveLogEntry(String walletId, String stockName, String type) {
        logRepo.save(new AuditLogEntry(type, walletId, stockName));
    }
}