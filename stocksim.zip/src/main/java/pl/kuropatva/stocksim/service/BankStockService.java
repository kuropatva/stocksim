package pl.kuropatva.stocksim.service;


import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.kuropatva.stocksim.mapper.StockMapper;
import pl.kuropatva.stocksim.model.dto.web.StockListDto;
import pl.kuropatva.stocksim.repository.StockRepository;

@Service
public class BankStockService {

    @Autowired
    private StockRepository stockRepository;
    @Autowired
    private StockMapper stockMapper;

    public StockListDto getAllStocks() {
        return stockMapper.toListDto(stockRepository.findAllByWalletId(null));
    }

    @Transactional
    public void setAllStocks(StockListDto stocks) {
        stockRepository.deleteAllByWalletId(null);
        stockRepository.saveAll(stockMapper.toEntityList(stocks));
    }
}
