package pl.kuropatva.stocksim.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.kuropatva.stocksim.mapper.StockMapper;
import pl.kuropatva.stocksim.model.dto.web.WalletDto;
import pl.kuropatva.stocksim.repository.StockRepository;
import pl.kuropatva.stocksim.repository.WalletRepository;

@Service
public class WalletService {

    @Autowired
    private WalletRepository walletRepository;
    @Autowired
    private StockRepository stockRepository;
    @Autowired
    private StockMapper stockMapper;

    public WalletDto getAllStocks(String walletId) {
        var wallet = walletRepository.findById(walletId);
        if (wallet.isEmpty()) return null;
        return new WalletDto(walletId, wallet.get().getStocks().stream().map(stockMapper::toDto).toList());
    }

    public long getStockQuantity(String walletId, String stockName) {
        var stock = stockRepository.findByNameAndWalletId(stockName, walletId);
        if (stock.isEmpty()) return 0;
        return stock.get().getQuantity();
    }
}
